"""③ 第二层剥洋葱：HBM 自由后的隐形杀手 —— L2 Cache 瓶颈"""
import matplotlib.pyplot as plt
from roofline_common import base, roof, BW_L2

fig, ax = plt.subplots(figsize=(9, 6))
base(ax, show_ub=False)

ai_hbm = 150
ai_l2 = 10
perf = roof(ai_l2, BW_L2) # 40

ax.plot(ai_hbm, perf, 'ro', ms=10, alpha=0.5) # HBM 视角的点
ax.plot(ai_l2, perf, 'o', color='#ff7f0e', ms=12) # L2 视角的点

ax.plot([ai_l2, ai_hbm], [perf, perf], 'k:', lw=1.5)

ax.annotate('红点：HBM AI 极高\n看似已是 Compute-bound', (ai_hbm, perf), xytext=(ai_hbm*0.3, perf*0.3),
            color='#d62728', arrowprops=dict(arrowstyle='->', color='#d62728'))

ax.annotate('橙点：实则卡在 L2 屋檐！\n需优化多核数据共享 / L2 Tiling', (ai_l2, perf), xytext=(ai_l2*0.2, perf*1.8),
            color='#ff7f0e', arrowprops=dict(arrowstyle='->', color='#ff7f0e'))

ax.set_title('③ 第二层剥洋葱：HBM 自由后的隐形杀手 —— 引入 L2 屋檐')
plt.tight_layout()
plt.savefig('fig3_l2_bound.png', dpi=140)
