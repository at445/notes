"""公共参数 + 画底图函数，供现代 NPU 多级 Roofline 复用。"""
import numpy as np
import matplotlib.pyplot as plt

plt.rcParams['font.sans-serif'] = ['Microsoft YaHei', 'SimHei', 'Arial']
plt.rcParams['axes.unicode_minus'] = False

# ---------------- 现代 NPU 硬件参数 (三道屋檐) ----------------
C = 100.         # Cube 算力顶 (TFLOP/s)
BW_HBM = 1.      # HBM 理论带宽 (TB/s)
BW_L2 = 4.       # L2 Cache 理论带宽 (TB/s)
BW_UB = 15.      # UB (Unified Buffer) 理论带宽 (TB/s)
BW_BC = 3.       # UB 发生 Bank Conflict 时的实际带宽 (TB/s)

AI = np.logspace(-2, 4, 800)
RIDGE_HBM = C / BW_HBM  # 100
RIDGE_L2  = C / BW_L2   # 25
RIDGE_UB  = C / BW_UB   # 6.67

def roof(x, bw):
    """屋檐 = min(算力顶, 带宽 * AI)。"""
    return np.minimum(C, bw * x)

def base(ax, show_hbm=True, show_l2=True, show_ub=True, show_bc=False):
    """画底图：HBM、L2、UB 三道屋檐"""
    if show_hbm:
        ax.plot(AI, roof(AI, BW_HBM), color='#d62728', lw=2, label=f'HBM 屋檐 ({BW_HBM} TB/s)')
    if show_l2:
        ax.plot(AI, roof(AI, BW_L2), color='#ff7f0e', lw=2, label=f'L2 屋檐 ({BW_L2} TB/s)')
    if show_ub:
        ax.plot(AI, roof(AI, BW_UB), color='#1f77b4', lw=2, label=f'UB 屋檐 ({BW_UB} TB/s)')
    if show_bc:
        ax.plot(AI, roof(AI, BW_BC), color='#1f77b4', ls='--', lw=1.8, alpha=0.7, label=f'UB Bank Conflict ({BW_BC} TB/s)')
    
    ax.axhline(C, ls='--', color='k', label=f'Cube 算力顶 ({C:.0f} TFLOP/s)')
    ax.set_xscale('log'); ax.set_yscale('log')
    ax.set_xlim(0.1, 1e4); ax.set_ylim(0.5, 250)
    ax.set_xlabel('算术强度 AI (FLOP/Byte)'); ax.set_ylabel('性能 (TFLOP/s)')
    ax.grid(True, which='both', ls=':', alpha=0.4)
    ax.legend(loc='lower right', fontsize=9)
