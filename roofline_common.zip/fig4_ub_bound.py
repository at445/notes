"""④ 第三层剥洋葱：决战核心 —— UB 带宽受限与 L0 Tiling 优化"""
import matplotlib.pyplot as plt
from roofline_common import base, roof, BW_UB

fig, ax = plt.subplots(figsize=(9, 6))
base(ax)

ai_l2 = 80
ai_ub = 4
perf = roof(ai_ub, BW_UB) # 60

ax.plot(ai_l2, perf, 'o', color='#ff7f0e', ms=10, alpha=0.5)
ax.plot(ai_ub, perf, 'o', color='#1f77b4', ms=12)
ax.plot([ai_ub, ai_l2], [perf, perf], 'k:', lw=1.5)

ax.annotate('橙点越过拐点\nL2 带宽也自由了', (ai_l2, perf), xytext=(ai_l2*1.2, perf*0.5),
            color='#ff7f0e', arrowprops=dict(arrowstyle='->', color='#ff7f0e', lw=1))

ax.annotate('蓝点卡在 UB 屋檐\n优化 L0 Tiling / Dataflow\n增加 Cube 内复用，推高 UB AI', (ai_ub, perf), xytext=(ai_ub*0.8, perf*2.0),
            color='#1f77b4', arrowprops=dict(arrowstyle='->', color='#1f77b4', lw=2))

ax.set_title('④ 第三层剥洋葱：决战核心 —— UB 带宽受限与 L0 Tiling 优化')
plt.tight_layout()
plt.savefig('fig4_ub_bound.png', dpi=140)
