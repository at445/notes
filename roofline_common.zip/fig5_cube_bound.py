"""⑤ 登顶 Cube 算力峰值：消灭 UB Bank 冲突与矩阵 Padding 气泡"""
import matplotlib.pyplot as plt
from roofline_common import base, roof, C, BW_BC

fig, ax = plt.subplots(figsize=(9, 6))
base(ax, show_bc=True)

ai_ub = 30 # 处于平段

# 情况 1: Bank Conflict
perf_bc = roof(ai_ub, BW_BC)
ax.plot(ai_ub, perf_bc, 's', color='#1f77b4', ms=10)
ax.annotate('现象 A：UB Bank Conflict\n虽在平段，实际带宽暴跌', (ai_ub, perf_bc), xytext=(ai_ub*1.5, perf_bc*0.6),
            color='#1f77b4', arrowprops=dict(arrowstyle='->', color='#1f77b4'))

# 情况 2: Cube Padding
perf_pad = 75
ax.plot(ai_ub, perf_pad, '^', color='k', ms=12)
ax.annotate('现象 B：Cube 没喂饱\n(如 16x16 Padding 气泡 / 流水线空干)', (ai_ub, perf_pad), xytext=(ai_ub*1.5, perf_pad*1.2),
            color='k', arrowprops=dict(arrowstyle='->', color='k'))

ax.set_title('⑤ 登顶 Cube 算力峰值：消灭 UB Bank 冲突与矩阵 Padding 气泡')
plt.tight_layout()
plt.savefig('fig5_cube_bound.png', dpi=140)
