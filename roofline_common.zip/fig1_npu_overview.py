"""① 现代 NPU 多级 Roofline：HBM、L2、UB 三道屋檐"""
import matplotlib.pyplot as plt
from roofline_common import base

fig, ax = plt.subplots(figsize=(9, 6))
base(ax)

ax.annotate('HBM 瓶颈区\n(卡片外访存)', xy=(2, 1.5), color='#d62728', fontsize=11, weight='bold')
ax.annotate('L2 瓶颈区\n(卡多核共享)', xy=(8, 20), color='#ff7f0e', fontsize=11, weight='bold')
ax.annotate('UB 瓶颈区\n(卡单核吞吐)', xy=(15, 80), color='#1f77b4', fontsize=11, weight='bold')
ax.annotate('Cube 算力瓶颈区\n(真 Compute-bound)', xy=(200, 120), color='k', fontsize=11, weight='bold')

ax.set_title('① 现代 NPU 架构全景：三道屋檐层层设卡，算力登顶之路')
plt.tight_layout()
plt.savefig('fig1_npu_overview.png', dpi=140)
