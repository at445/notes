"""② 第一层剥洋葱：突破 HBM 瓶颈"""
import matplotlib.pyplot as plt
from roofline_common import base, roof, BW_HBM

fig, ax = plt.subplots(figsize=(9, 6))
base(ax, show_l2=False, show_ub=False)

ai_start = 5
perf = roof(ai_start, BW_HBM)
ax.plot(ai_start, perf, 'ro', ms=12)

ai_end = 30
ax.annotate('', (ai_end, perf), (ai_start, perf), arrowprops=dict(arrowstyle='->', color='#d62728', lw=2))
ax.plot(ai_end, perf, 'ro', ms=12, mfc='none')

ax.text(8, perf * 1.2, '算子融合 / 全局 Tiling\n→ 减少 HBM 读写\n→ 推高 HBM AI', color='#d62728', fontsize=10)

ax.set_title('② 第一层剥洋葱：突破 HBM 瓶颈 (Global Memory)')
plt.tight_layout()
plt.savefig('fig2_hbm_bound.png', dpi=140)
